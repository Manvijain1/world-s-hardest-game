var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["f363b9ff-bac0-45c0-bd12-e8ed37680acf","cd8676b0-6266-44dc-a8b3-ace712f89fe8","10d01c03-5e5d-4200-9fca-8fcca1d0266d","2bf761d5-7799-4e2a-a2dc-563fa52eb82d","f440ed7b-6160-4ff3-aff8-54f2e4efc4c8"],"propsByKey":{"f363b9ff-bac0-45c0-bd12-e8ed37680acf":{"name":"car","sourceUrl":null,"frameSize":{"x":50,"y":36},"frameCount":1,"looping":true,"frameDelay":12,"version":"eWk3JZXJCVa2aTWYHI5eozIJS7173SO9","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":36},"rootRelativePath":"assets/f363b9ff-bac0-45c0-bd12-e8ed37680acf.png"},"cd8676b0-6266-44dc-a8b3-ace712f89fe8":{"name":"car2","sourceUrl":null,"frameSize":{"x":20,"y":37},"frameCount":1,"looping":true,"frameDelay":12,"version":"FXoG2kzHho39lw57pvmfGpxEjOrM1OAV","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":37},"rootRelativePath":"assets/cd8676b0-6266-44dc-a8b3-ace712f89fe8.png"},"10d01c03-5e5d-4200-9fca-8fcca1d0266d":{"name":"road","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"jUOFzXfmBzXw7Y1NRK4bGgSQBFUojhPB","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/10d01c03-5e5d-4200-9fca-8fcca1d0266d.png"},"2bf761d5-7799-4e2a-a2dc-563fa52eb82d":{"name":"paddle","sourceUrl":null,"frameSize":{"x":200,"y":72},"frameCount":1,"looping":true,"frameDelay":12,"version":"fJHveiXSFKhJuU1BaMJ1dPFKouyj35TR","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":72},"rootRelativePath":"assets/2bf761d5-7799-4e2a-a2dc-563fa52eb82d.png"},"f440ed7b-6160-4ff3-aff8-54f2e4efc4c8":{"name":"paddle2","sourceUrl":null,"frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":12,"version":"cbTOqqmetgfhPrKF3Q7AkAbBXuhMYkrh","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/f440ed7b-6160-4ff3-aff8-54f2e4efc4c8.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var paddle = createSprite(200,50);
paddle.setAnimation("paddle");
paddle.setVelocity(0,-0.5);

var paddle2 = createSprite(200,150)
paddle2.setAnimation("paddle2")
paddle2.setVelocity(0,-0.5)




var back = createSprite(200,250);
back.setAnimation("road");

var car = createSprite(200,350,20,20);
car.setAnimation("car");
car.setVelocity(0,0);

var car2 = createSprite(160,250);
car2.setAnimation("car2");


var car3 = createSprite (230,190);
car3.setAnimation("car2");


var car4 = createSprite (170,280);
car4.setAnimation("car2")


var car5 = createSprite (250,300);
car5.setAnimation("car2");



var car6 = createSprite (250,360);
car6.setAnimation("car2");



var car7 = createSprite (150,350);
car7.setAnimation("car2");


var car8 = createSprite (200,280);
car8.setAnimation("car2");


var line1 = createSprite(130,200,5,400);
line1.shapeColor = "white";

var line2 = createSprite(270,200,5,400);
line2.shapeColor = "white";

var line3 = createSprite(200,50,400,5);
line3.shapeColor = "black"




 var score = 0;
 var life = 5
 
 
 
 
function draw() {
  background("lavender");
   createEdgeSprites();
   
  car.collide(line1)
  car.collide(line2)
  car.collide(line3)
  car.collide(bottomEdge)
     
 if (keyDown("ENTER")){
      car2.setVelocity(0,-1);
      car3.setVelocity(0,-1);
      car4.setVelocity(0,-1);
      car5.setVelocity(0,-1);
      car6.setVelocity(0,-1);
      car7.setVelocity(0,-1);
      car8.setVelocity(0,-1);
 }
    
       if (keyWentDown("UP_ARROW")){
  car.velocityY = -3
  
}

if (keyWentUp("up")){
  car.setVelocity(0,0)
}

if (keyWentDown("DOWN_ARROW")){
   car.velocityY = 3
   
}
if (keyWentUp("down")){
  car.setVelocity(0,0)
}

if (keyWentDown("LEFT_ARROW")){
   car.velocityX = -3
   
}

if (keyWentUp("left")){
  car.setVelocity(0,0)
}

if (keyWentDown("RIGHT_ARROW")){
 car.velocityX = 3
 
}

if (keyWentUp("right")){
  car.setVelocity(0,0)
}
    
    
   
   
   
   

 if (car.isTouching(car2)){
  car2.destroy()
  score = score+1
}

if (car.isTouching(car3)){
  car3.destroy()
  score = score+1
}

if (car.isTouching(car4)){
  car4.destroy()
  score = score+1
}

if (car.isTouching(car5)){
  car5.destroy()
  score = score+1
}
 
 if (car.isTouching(car6)){
  car6.destroy()
  score = score+1
}
if (car.isTouching(car7)){
  car7.destroy()
  score = score+1
}
 
if (car.isTouching(car8)){
  car8.destroy()
  score = score+1
}



if (car3.isTouching(line3)){
  car3.destroy()
  life = life-1
}

if (car2.isTouching(line3)){
  car2.destroy()
  life = life-1
}

if (car4.isTouching(line3)){
  car4.destroy()
  life = life-1
}

if (car5.isTouching(line3)){
  car5.destroy()
  life = life-1
}


if (car6.isTouching(line3)){
  car6.destroy()
  life = life-1
}

if (car7.isTouching(line3)){
  car7.destroy()
  life = life-1
}

if (car8.isTouching(line3)){
  car8.destroy()
  life = life-1



  }    
   
 





     
   
   

  if (score == 5){
    
  stroke = "green"  
    textSize(30)
  
  text("YOU WON",130,25)
   
car.setVelocity(0,0)
  car2.setVelocity(0,0)
  car3.setVelocity(0,0)
  car4.setVelocity(0,0)
  car5.setVelocity(0,0)
  car6.setVelocity(0,0)
  car7.setVelocity(0,0)
  car8.setVelocity(0,0)
  
  
}

if (life == 0){
  
stroke = "red"  
  textSize(30)
  text("YOU LOSE",150,20)

  car.setVelocity(0,0)
  car2.setVelocity(0,0)
  car3.setVelocity(0,0)
  car4.setVelocity(0,0)
  car5.setVelocity(0,0)
  car6.setVelocity(0,0)
  car7.setVelocity(0,0)
  car8.setVelocity(0,0)
  
  
  
}
  
 
  
  
  
   
   











 
 textSize(20)
 text(score,380,20)
 text (life,100,20)
 text("Score:",320,20)
 text ("Life:",60,20)
 
 

   
   
   
   
   
   
   
   
   
   
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
